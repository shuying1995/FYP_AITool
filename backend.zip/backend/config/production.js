const config = {
    env: 'production',
    PrivateKey: process.env.PrivateKey
};

module.exports = config;