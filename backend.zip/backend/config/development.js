const config = {
    env: 'development',
    PrivateKey: process.env.PrivateKey
};

module.exports = config;